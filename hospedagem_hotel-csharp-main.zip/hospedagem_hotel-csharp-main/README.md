**Desafio**: Construindo um sistema de hospedagem de um hotel no C#.
